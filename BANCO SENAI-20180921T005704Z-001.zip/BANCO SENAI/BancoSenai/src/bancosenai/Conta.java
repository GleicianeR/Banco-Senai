package bancosenai;

import java.util.ArrayList;

public class Conta {

    private double saldo;
    private ArrayList<Double> extrato;
    //private double valorInicial;

    public Conta(double saldoInicial) {
        this.saldo = saldoInicial;
        this.extrato = new ArrayList<Double>();
    }

    /*private double valorInicial(){
        return valorInicial;
    }*/
    
    public double sacar(double saque) {
        if (saque <= saldo) {
            this.saldo = this.saldo - saque;
            this.extrato.add(-saque);
            return this.saldo;
        } else {
            return -1;
        }
    }

    public double depositar(double deposito) {
        this.saldo = this.saldo + deposito;
        this.extrato.add(deposito);
        return this.saldo = saldo;
    }

    public double consultarSaldo() {
        return this.saldo;
    }

    public ArrayList<Double> consultarExtrato() {
        return this.extrato;
    }

    public double saldo() {
        return this.saldo;
    }
}
