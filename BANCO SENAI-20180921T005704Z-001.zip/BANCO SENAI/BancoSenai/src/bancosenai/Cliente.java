package bancosenai;

//Classe do cliente
class Cliente {

    private String dataDeAbertura;
    private String nDaConta;
    private String codigo;
    private String nome;
    private String dataDeNascimento;
    private Conta conta;
    private double valorInicial;

    // private String setsalvarCliente;
    public Cliente() {
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDataDeNascimento() {
        return dataDeNascimento;
    }

    public void setDataDeNascimento(String dataDeNascimento) {
        this.dataDeNascimento = dataDeNascimento;
    }

    public Conta getConta() {
        return this.conta;
    }

    public void setConta(Conta conta) {
        this.conta = conta;
    }

    public String getNDaConta() {
        return nDaConta;
    }

    public void setNDaConta(String nDaConta) {
        this.nDaConta = nDaConta;
    }

    /*double setCodigo(double codigo) {
       return codigo;
    }*/
    
    public String getDataDeAbertura() {
        return dataDeAbertura;
    }

    public void setDataDeAbertura(String dataDeAbertura) {
        this.dataDeAbertura = dataDeAbertura;
    }

    public double getValorInicial() {
        return valorInicial;
    }

    public void setValorInicial(double valorInicial) {
        this.valorInicial = valorInicial;
    }

}
