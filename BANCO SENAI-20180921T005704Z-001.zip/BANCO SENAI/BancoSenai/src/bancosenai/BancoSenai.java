package bancosenai;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
        
import java.util.Scanner;

//Declaração da classe.
public class BancoSenai {

    //Modificador da classe Cliente. Não pode ser acessada por nenhuma outra classe.
    private static Cliente cliente;

    //Classe para tipos primitivos e strings.
    private static Scanner scan = new Scanner(System.in);
    private static String codigo;
    private static String sacar;
    private static String depositar;

    //Corpo principal onde é iniciada a execução do programa.
    public static void main(String[] args) {
        logar();
    }

    //Metodo logar que exige nome e senha como segurança para ter acesso ao menu principal. 
    public static void logar() {
        int erro = 0;
        System.out.println("Login: ");
        String login = scan.nextLine();
        System.out.println("");
        System.out.println("Senha: ");
        String senha = scan.nextLine();

        try {
            FileReader arq = new FileReader("login.csv");
            BufferedReader lerArq = new BufferedReader(arq);
            String linha = lerArq.readLine();
            String nomeUsuario = "";
            while (linha != null) {
                String[] vetorLogin = linha.split(";");
                if (vetorLogin[0].equals(login) && vetorLogin[1].equals(senha)) { //Vetores que irão alocar as variáveis do login.
                    erro = 10;
                    nomeUsuario = vetorLogin[2];
                }
                linha = lerArq.readLine();
            }
            arq.close();
            if (erro != 10) {
                System.out.println("Login ou senha errada!");
            } else {
                System.out.println("");
                System.out.println("   Seja Bem vindo(a), " + nomeUsuario + "!");
                exibirMenuCliente();
            }
        } catch (IOException e) {
            System.out.println("Erro na abertura do arquivo");
        }
    }

    //Menu principal.
    private static void exibirMenuCliente() throws IOException {

        int opcao = -1;

        while (opcao != 9) {

            System.out.println("");
            System.out.println("         BANCO SENAI        ");
            System.out.println("");
            System.out.println("--------- MENU CLIENTE ---------");
            System.out.println("                               |");
            System.out.println(" 1- Cadastrar Cliente          |");
            System.out.println(" 2- Consultar Cliente          |");
            System.out.println(" 3- Listar Clientes Cadastrados|");
            System.out.println("(9) Encerrar/Sair do Sistema   |");
            System.out.println("                               |");
            System.out.println("  Escolha uma opção:           |");
            System.out.println("--------------------------------");

            opcao = scan.nextInt();

            //Estrutura que controla várias ações diferentes de acordo com o caso definido dentro dele.    
            switch (opcao) {
                case 1:
                    cadastrarCliente();
                    break;

                case 2:
                    consultarCliente();
                    break;

                case 3:
                    listarClientesCadastrados();
                    break;

                case 9:
                    System.out.println("Operação Encerrada!");
                    break;

                default:
                    System.out.println("Opção inválida!");
                    break;
            }
        }
    }

    private static void cadastrarCliente() throws IOException {
        scan.nextLine(); //Metodo que imprime o resultado.
        System.out.println("");
        System.out.println("Preencha os campos abaixo:");
        System.out.println("");
        System.out.println("Código: ");
        codigo = scan.nextLine();

        //Ler o arquivo
        FileReader arqCliente = new FileReader("cliente.csv");
        BufferedReader lerArqCliente = new BufferedReader(arqCliente);
        String linhaCliente = lerArqCliente.readLine();

        //Variável boleana para verificar
        boolean verificarCodigo = false;

        //Equanto a linha do arquivo for nula
        while (linhaCliente != null) {

            //Quebra de linha
            String[] vetorCodigo = linhaCliente.split(";");

            //Se o código for igual a alguma posição do seu vetor
            if (codigo.equals(vetorCodigo[0])) {
                verificarCodigo = true; //Boleana se torna verdadeira pois já fez a comparação    
            }
            linhaCliente = lerArqCliente.readLine();
        }
        if (verificarCodigo == false) {
            System.out.println("");
            System.out.println("Nome: ");
            String nome = scan.nextLine();
            System.out.println("");
            System.out.println("Data de Nascimento: ");
            String dataDeNascimento = scan.nextLine();
            cliente = new Cliente(); //Inicializar cliente.
            cliente.setCodigo(codigo);
            cliente.setNome(nome);
            cliente.setDataDeNascimento(dataDeNascimento);
            salvarCliente();
        } else {
            System.out.println("");
            System.out.println("Código já cadastrado!");
            exibirMenuCliente();
        }
    }

    private static void salvarCliente() {
        //Tratameto de exceções ,ou seja , erros que ocorrem em tempo de execução.
        try { //"Captura" o erro.
            FileWriter fileWriter = new FileWriter("cliente.csv", true); //Nome do arquivo csv do cliente.
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            String linha = cliente.getCodigo() + ";" + cliente.getNome() + ";" + cliente.getDataDeNascimento();
            bufferedWriter.write(linha);
            bufferedWriter.newLine();
            bufferedWriter.close();
        } catch (FileNotFoundException e) { //Trata o erro.
            System.out.println("Não foi possivel acessar o arquivo.");
        } catch (IOException ioe) {
            System.out.println("Erro na escrita do arquivo.");
        }
    }

    private static void consultarCliente() throws FileNotFoundException, IOException {
        scan.nextLine();

        System.out.println("Informe o código:");
        codigo = scan.nextLine();
        System.out.println("");
        //Ler o arquivo
        FileReader arqCliente = new FileReader("cliente.csv");
        BufferedReader lerArqCliente = new BufferedReader(arqCliente);
        String linhaCliente = lerArqCliente.readLine();

        //Variável boleana para verificar
        boolean verificarCodigo = false;

        //Equanto a linha do arquivo for nula
        while (linhaCliente != null) {
            //Quebra de linha
            String[] vetorCodigo = linhaCliente.split(";");

            //Se o código for igual a alguma posição do seu vetor
            if (codigo.equals(vetorCodigo[0])) {
                verificarCodigo = true; //Boleana se torna verdadeira pois já fez a comparação    
                System.out.println("");
                System.out.println("Código: " + vetorCodigo[0]);
                System.out.println("Nome: " + vetorCodigo[1]);
                System.out.println("Data de Nascimento: " + vetorCodigo[2]);
                System.out.println("");
                exibirMenuConta();
            }
            linhaCliente = lerArqCliente.readLine();
        }
        if (verificarCodigo == false) {
            System.out.println("Cliente não cadastrado!"); //Mensagem exibida caso não exista nenhum cliente cadastrado com o código informado.
            
        }   
    }

    private static void listarClientesCadastrados() {

        int erro = 0;

        try {
            FileReader arq = new FileReader("cliente.csv");
            BufferedReader lerArq = new BufferedReader(arq);
            String linha = lerArq.readLine();
            String[] vetorCliente;

            while (linha != null) {
                vetorCliente = linha.split(";");
                System.out.println(" Codigo: " + vetorCliente[0] + " Nome: " + vetorCliente[1]);
                erro = 1; //Caso haja algum cliente listado.
                linha = lerArq.readLine();
            }
            if (erro == 0) {
                System.out.println("Nenhum cliente encontrado"); //Mensagem exibida caso não tenha nenhum cliente listado.
            }
            arq.close();
        } catch (IOException e) {
            System.out.println("Erro na abertura do arquivo");
        }
    }

    //Menu secundário.
    private static void exibirMenuConta() throws IOException {

        int opcao = -1;

        while (opcao != 9) {

            System.out.println("         BANCO SENAI        ");
            System.out.println("");
            System.out.println("------------ MENU CONTA -------------");
            System.out.println(" 1- Cadastrar conta                 |");       
            System.out.println(" 2- Listar contas cadastradas       |");
            System.out.println(" 3- Sacar                           |");
            System.out.println(" 4- Depositar                       |");
            System.out.println(" 5- Consulta extrato                |");
            System.out.println("(9) Retornar ao Menu Cliente        |");
            System.out.println("                                    |");
            System.out.println("    Escolha uma opção:              |");
            System.out.println("-------------------------------------");
            
            opcao = scan.nextInt();

            switch (opcao) {
                case 1:
                    cadastrarConta();
                    break;

                case 2:
                    listarContasCadastradas();
                    break;

                case 3:
                    sacar();
                    break;

                case 4:
                    depositar();
                    break;

                case 5:
                    consultarExtrato();
                    break;

                case 9:         
                    break;

                default:
                    System.out.println("Opção inválida!");
                    break;
            }
        }
    }

    private static void cadastrarConta() throws FileNotFoundException, IOException {
        scan.nextLine();
        System.out.println("Insira o número da conta:");
        String nDaConta = scan.nextLine();

        //Ler o arquivo
        FileReader arqNConta = new FileReader("conta.csv");
        BufferedReader lerArqNConta = new BufferedReader(arqNConta);
        String linhaNConta = lerArqNConta.readLine();

        //Variável boleana para verificar
        boolean verificarNDaConta = false;

        //Equanto a linha do arquivo for nula
        while (linhaNConta != null) {

            //Quebra de linha
            String[] vetorNDaConta = linhaNConta.split(";");

            //Se o código for igual a alguma posição do seu vetor
            if (nDaConta.equals(vetorNDaConta[0])) {
                verificarNDaConta = true; //Boleana se torna verdadeira pois já fez a comparação    
                System.out.println("");
                System.out.println(" Número de conta já cadastrado!");
            }
            linhaNConta = lerArqNConta.readLine();
        }
        if (verificarNDaConta == false) {
            System.out.println("Informe a data:");
            String data = scan.nextLine();
            System.out.println("Valor inicial da conta:");
            String depositoInicial = scan.nextLine();
            System.out.println(""); 
            cliente.setNDaConta(nDaConta);
           
            salvarConta();

            FileWriter sDeposito = new FileWriter("extrato.csv", true);
            BufferedWriter bufferedWriter = new BufferedWriter(sDeposito);
            Date dataOperacao = new Date();
            String linha = depositoInicial + ";" + dataOperacao + ";" + nDaConta;
            bufferedWriter.write(linha);
            bufferedWriter.newLine();
            bufferedWriter.close();
            sDeposito.close();
        }
    }

    private static void salvarConta() {
        try { //"Captura" o erro.
            FileWriter sConta = new FileWriter("conta.csv", true); //Nome do arquivo csv do cliente.
            BufferedWriter bufferedWriter = new BufferedWriter(sConta);
            Date dataAtual = new Date();
            String linha = cliente.getNDaConta() + ";" + dataAtual + ";" + codigo;
            bufferedWriter.write(linha);
            bufferedWriter.newLine();
            bufferedWriter.close();
            sConta.close();
        } catch (FileNotFoundException e) { //Trata o erro.
            System.out.println("Não foi possivel acessar o arquivo.");
        } catch (IOException ioe) {
            System.out.println("Erro na escrita do arquivo.");
        }
    }
  
    private static void listarContasCadastradas() {
        int erro = 0;

        try {
            FileReader arq = new FileReader("conta.csv");
            BufferedReader lerArq = new BufferedReader(arq);
            String linha = lerArq.readLine();
            String[] vetorConta;

            while (linha != null) {
                vetorConta = linha.split(";");
                if (codigo.equals(vetorConta[2])) {
                    System.out.println("");
                    System.out.println("N° da Conta: " + vetorConta[0]);
                    System.out.println("Código do Cliente: " + vetorConta[2]);
                    System.out.println("Data de abertura: " + vetorConta[1]);
                    System.out.println("");

                    erro = 1; //Caso haja algum cliente listado.
                }
                linha = lerArq.readLine();
            }
            if (erro == 0) {
                System.out.println("Nenhuma conta cadastrada!"); //Mensagem exibida caso não tenha nenhum cliente listado.
            }
            lerArq.close();
            arq.close();
        } catch (IOException e) {
            System.out.println("Erro na abertura do arquivo"); //Mensagem exibida caso nome de arquivo csv esteja incorreto. 
        }
    }

    private static void sacar() throws FileNotFoundException, IOException {
        scan.nextLine();
        System.out.println("Informe o número da conta:");
        String nDaConta = scan.nextLine();

        //Ler o arquivo
        FileReader arqNConta = new FileReader("conta.csv");
        BufferedReader lerArqNConta = new BufferedReader(arqNConta);
        String linhaNConta = lerArqNConta.readLine();

        boolean verificarNDaConta = false;

        while (linhaNConta != null) {
            String[] vetorCodigo = linhaNConta.split(";");

            if (nDaConta.equals(vetorCodigo[0]) && codigo.equals(vetorCodigo[2])) {
                verificarNDaConta = true; //Boleana se torna verdadeira pois já fez a comparação    
            }
            linhaNConta = lerArqNConta.readLine();
        }
        if (verificarNDaConta == true) {
            System.out.println("Informe o valor do saque: ");
            sacar = scan.nextLine();

            salvarSaque(nDaConta);
        } else {
            System.out.println("");
            System.out.println(" Conta não encontrada! ");
        }
        lerArqNConta.close();
        arqNConta.close();
    }

    private static void salvarSaque(String nDaConta) {
        try {
            FileWriter sSaque = new FileWriter("extrato.csv", true);
            BufferedWriter bufferedWriter = new BufferedWriter(sSaque);
            Date dataSaque = new Date();
            String linha = "-" + sacar + ";" + dataSaque + ";" + nDaConta;
            bufferedWriter.write(linha);
            bufferedWriter.newLine();
            bufferedWriter.close();
            sSaque.close();
        } catch (FileNotFoundException e) { //Trata o erro.
            System.out.println("Não foi possivel acessar o arquivo.");
        } catch (IOException ioe) {
            System.out.println("Erro na escrita do arquivo.");
        }

    }

    private static void depositar() throws FileNotFoundException, IOException {
        scan.nextLine();
        System.out.println("Informe o número da conta: ");
        String nDaConta = scan.nextLine();

        //Ler o arquivo
        FileReader arqNConta = new FileReader("conta.csv");
        BufferedReader lerArqNConta = new BufferedReader(arqNConta);
        String linhaNConta = lerArqNConta.readLine();

        boolean verificarNDaConta = false;

        while (linhaNConta != null) {
            String[] vetorCodigo = linhaNConta.split(";");

            if (nDaConta.equals(vetorCodigo[0]) && codigo.equals(vetorCodigo[2])) {
                verificarNDaConta = true; //Boleana se torna verdadeira pois já fez a comparação    
            }
            linhaNConta = lerArqNConta.readLine();
        }
        if (verificarNDaConta == true) {
            System.out.println("Informe o valor de deposito:");
            depositar = scan.nextLine();

            salvarDeposito(nDaConta);
        } else {
            System.out.println("");
            System.out.println(" Conta não encontrada!"); //Mensagem exibida quando não for encontrado conta para o número informado.
        }
        lerArqNConta.close();
        arqNConta.close();
    }

    private static void salvarDeposito(String nDaConta) {
        try {
            FileWriter sDeposito = new FileWriter("extrato.csv", true);
            BufferedWriter bufferedWriter = new BufferedWriter(sDeposito);
            Date dataDeposito = new Date();
            String linha = depositar + ";" + dataDeposito + ";" + nDaConta;
            bufferedWriter.write(linha);
            bufferedWriter.newLine();
            bufferedWriter.close();
            sDeposito.close();
        } catch (FileNotFoundException e) { //Trata o erro.
            System.out.println("Não foi possivel acessar o arquivo.");
        } catch (IOException ioe) {
            System.out.println("Erro na escrita do arquivo.");
        }
    }
      
    private static void consultarExtrato() throws FileNotFoundException, IOException {
        scan.nextLine();
        System.out.println("Informe o número da conta:");
        String nDaConta = scan.nextLine();

        //Ler o arquivo
        FileReader arqNConta = new FileReader("conta.csv");
        BufferedReader lerArqNConta = new BufferedReader(arqNConta);
        String linhaNConta = lerArqNConta.readLine();

        boolean verificarNDaConta = false;

        while (linhaNConta != null) {
            String[] vetorCodigo = linhaNConta.split(";");

            if (nDaConta.equals(vetorCodigo[0]) && codigo.equals(vetorCodigo[2])) {
                verificarNDaConta = true; //Boleana se torna verdadeira pois já fez a comparação    
            }
            linhaNConta = lerArqNConta.readLine();
        }
        if (verificarNDaConta == false) {
            System.out.println("");
            System.out.println("Número de conta não existe ou pertence a outro usuário!");
        }
        if (verificarNDaConta == true) {

            int erro = 0;

            try {
                FileReader arq = new FileReader("extrato.csv");
                BufferedReader lerArq = new BufferedReader(arq);
                String linha = lerArq.readLine();
                String[] vetorExtrato;

                while (linha != null) {

                    vetorExtrato = linha.split(";");

                    if (nDaConta.equals(vetorExtrato[2])) {
                        System.out.println("");
                        System.out.println(vetorExtrato[0]);
                        System.out.println(vetorExtrato[1]);
                        System.out.println("");

                        erro = 1; //Caso haja algum cliente listado.
                    }
                    linha = lerArq.readLine();
                }
                if (erro == 0) {
                    System.out.println("Nenhuma operação realizada!"); //Mensagem exibida caso não tenha nenhum cliente listado.
                }
                lerArqNConta.close();
                arq.close();
            } catch (IOException e) {
                System.out.println("Erro na abertura do arquivo");
            }
            arqNConta.close();
            lerArqNConta.close();
        }
    }
}
